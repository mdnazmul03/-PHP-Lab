<?php
/**
 * init_db.php
 * Creates a tiny SQLite database (users.db) with a users table
 * and some sample data, using PDO (no MySQL server needed).
 *
 * Run:
 *     php init_db.php
 */

$dbFile = __DIR__ . '/users.db';

// Start fresh each time this is run
if (file_exists($dbFile)) {
    unlink($dbFile);
}

$pdo = new PDO('sqlite:' . $dbFile);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$pdo->exec("
    CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'user'
    )
");

$stmt = $pdo->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
$stmt->execute(['admin', 'sup3rSecret!', 'admin']);
$stmt->execute(['alice', 'alicepass123', 'user']);
$stmt->execute(['bob',   'bobpass456',   'user']);

echo "users.db created with 3 sample users (admin, alice, bob).\n";
