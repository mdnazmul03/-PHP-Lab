<?php
/**
 * vulnerable_login.php
 * A DELIBERATELY INSECURE login endpoint, for learning purposes only.
 * It builds a SQL query by pasting user input directly into a string.
 *
 * Run:
 *     php init_db.php
 *     php -S 127.0.0.1:8000
 * Then visit e.g.:
 *     http://127.0.0.1:8000/vulnerable_login.php?username=admin&password=wrong
 *     http://127.0.0.1:8000/vulnerable_login.php?username=admin' -- &password=anything
 */

header('Content-Type: text/plain');

$dbFile = __DIR__ . '/users.db';
$pdo = new PDO('sqlite:' . $dbFile);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_SILENT);

$username = $_GET['username'] ?? '';
$password = $_GET['password'] ?? '';

// --- VULNERABLE LINE ---
// User input is concatenated straight into the SQL string.
// An attacker can change the *meaning* of the query, not just the data.
$query = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
echo "Running query: $query\n\n";

$result = $pdo->query($query);

if ($result === false) {
    $err = $pdo->errorInfo();
    echo "SQL error (this itself leaks info to an attacker): " . $err[2] . "\n";
    exit;
}

$row = $result->fetch(PDO::FETCH_ASSOC);

if ($row) {
    echo "Login successful! Welcome '{$row['username']}' (role: {$row['role']})";
} else {
    echo "Login failed";
}
