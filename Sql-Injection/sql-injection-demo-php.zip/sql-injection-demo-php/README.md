# SQL Injection Demo — PHP Version (Vulnerable vs. Fixed)

A tiny, self-contained PHP project to *see* SQL Injection happen, and
see how a prepared statement stops it. Uses SQLite via PDO, so no
MySQL server setup is needed. For learning on your own machine only —
never test techniques like this against systems you don't own or have
permission to test.

## Requirements

- PHP 8+ with the `pdo_sqlite` extension (enabled by default in most
  PHP installs).

## Setup

```bash
php init_db.php              # creates users.db with 3 sample users
php -S 127.0.0.1:8000        # starts PHP's built-in dev server
```

Then open `http://127.0.0.1:8000/index.html` in your browser — it has
two small forms pre-filled with an attack payload, one hitting the
vulnerable endpoint, one hitting the safe endpoint.

Sample users created:
| username | password       | role  |
|----------|----------------|-------|
| admin    | sup3rSecret!   | admin |
| alice    | alicepass123   | user  |
| bob      | bobpass456     | user  |

## 1. The VULNERABLE endpoint

Normal login (works as expected):
```
http://127.0.0.1:8000/vulnerable_login.php?username=admin&password=sup3rSecret!
```

Now try logging in as admin **without knowing the password**:
```
http://127.0.0.1:8000/vulnerable_login.php?username=admin' -- &password=anything
```

What happens: the script builds this query behind the scenes:
```sql
SELECT * FROM users WHERE username = 'admin' -- ' AND password = 'anything'
```
The `--` starts a SQL comment, so everything after it is ignored. The
password check disappears entirely, and you're logged in as admin.

## 2. The FIXED endpoint

Try the exact same attack against the safe version:
```
http://127.0.0.1:8000/safe_login.php?username=admin' -- &password=anything
```

This time it just fails. The safe version uses a **prepared statement**
(`WHERE username = ? AND password = ?`), so whatever you type is always
treated as plain data — it can never rewrite the SQL statement itself.

## The one-line fix

```php
// VULNERABLE
$query = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
$result = $pdo->query($query);

// SAFE
$stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND password = ?");
$stmt->execute([$username, $password]);
```

## Other real-world defenses worth knowing

- **Least privilege**: the DB user your app connects with shouldn't be able
  to drop tables or read unrelated databases.
- **Input validation**: reject obviously malformed input early (defense in
  depth — not a substitute for prepared statements).
- **Frameworks/ORMs** (Laravel's Eloquent, Doctrine, etc.) parameterize
  queries for you by default, which is part of why they're popular.
- **Hash passwords** (`password_hash()` / `password_verify()` in PHP) —
  this demo stores plaintext passwords only to keep the example
  readable; never do this for real.
