<?php
/**
 * safe_login.php
 * The FIXED version of the same login endpoint, using a prepared
 * (parameterized) statement. User input is passed separately from
 * the SQL, so it can never change the query's structure.
 *
 * Run:
 *     php init_db.php
 *     php -S 127.0.0.1:8000
 * Then try the same "attack" as vulnerable_login.php:
 *     http://127.0.0.1:8000/safe_login.php?username=admin' -- &password=anything
 * It will simply fail to log in, instead of bypassing auth.
 */

header('Content-Type: text/plain');

$dbFile = __DIR__ . '/users.db';
$pdo = new PDO('sqlite:' . $dbFile);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$username = $_GET['username'] ?? '';
$password = $_GET['password'] ?? '';

// --- SAFE LINE ---
// The "?" placeholders keep user input as pure data.
// PDO never lets it become part of the SQL syntax.
$stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND password = ?");
$stmt->execute([$username, $password]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if ($row) {
    echo "Login successful! Welcome '{$row['username']}' (role: {$row['role']})";
} else {
    echo "Login failed";
}
